
mbake .
mbake -t .
mbake -w .