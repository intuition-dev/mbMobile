# 
mbake www
mbake spa-ts-router
mbake -t spa-ts-router
npm start