

Note: Pay attention to ROOT in dat.yaml

You can run as http app if you have an http server, webroot is in app/www

npm start # to run

To create an exe:
npm run package-win


